
Run 'tiletel' to launch the telnet client.
By default it will connect to host 'dungeon.name' port 20028.
You can give a host and port on the command line to connect to another server, or simply edit 'default.cfg'.

